
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { siteConfig } from '../../config/site';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden bg-white dark:bg-slate-950">
      {/* Background decoration - matching logo colors */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-[600px] h-[600px] bg-purple-100/30 dark:bg-purple-900/10 rounded-full blur-3xl opacity-50"></div>
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-[400px] h-[400px] bg-cyan-100/30 dark:bg-cyan-900/10 rounded-full blur-3xl opacity-50"></div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 mb-8 rounded-full bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold uppercase tracking-[0.2em]">
            <span className="w-2 h-2 bg-cyan-500 rounded-full animate-pulse"></span>
            #1 Premium Digital Agency
          </div>
          
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-black text-slate-900 dark:text-white leading-[1] mb-8 tracking-tighter">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-indigo-500 to-cyan-500">
              Digital Dreams,
            </span><br />
            Explosive Result
          </h1>
          
          <p className="text-lg md:text-2xl text-slate-600 dark:text-slate-400 mb-12 max-w-3xl mx-auto leading-relaxed font-medium">
            We transform your ambitious ideas into high-performance digital reality. Custom websites, web apps, and mobile solutions for brands that demand the best.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-16">
            <Link 
              to="/projects"
              className="w-full sm:w-auto px-10 py-5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-black text-lg hover:scale-105 transition-all shadow-2xl flex items-center justify-center gap-2"
            >
              Explore Our Work
            </Link>
            <Link 
              to="/start-project"
              className="w-full sm:w-auto px-10 py-5 bg-gradient-to-r from-purple-600 to-cyan-500 text-white rounded-2xl font-black text-lg hover:scale-105 transition-all flex items-center justify-center gap-2 shadow-xl shadow-cyan-500/20"
            >
              Start Your Project <ArrowRight className="w-6 h-6" />
            </Link>
          </div>
          
          <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-6 pt-10 border-t border-slate-100 dark:border-slate-800">
            {siteConfig.trustPoints.map((point) => (
              <div key={point} className="flex items-center gap-3 text-slate-500 dark:text-slate-300 text-sm font-bold uppercase tracking-widest">
                <CheckCircle2 className="w-5 h-5 text-cyan-500" />
                {point}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
