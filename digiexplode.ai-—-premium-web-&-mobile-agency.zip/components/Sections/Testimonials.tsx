
import React from 'react';
import { testimonials } from '../../data/testimonials';
import { Quote } from 'lucide-react';

const Testimonials: React.FC = () => {
  return (
    <section className="py-24 bg-white dark:bg-slate-950">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-extrabold text-slate-900 dark:text-white mb-6">Client Success Stories</h2>
          <p className="text-slate-600 dark:text-slate-400 text-lg max-w-2xl mx-auto">
            Hear from the business owners who exploded their growth with our solutions.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t) => (
            <div key={t.id} className="p-8 rounded-3xl bg-slate-50 dark:bg-slate-900 relative">
              <Quote className="absolute top-6 right-8 w-10 h-10 text-indigo-200 dark:text-indigo-900/30" />
              <p className="text-slate-700 dark:text-slate-300 leading-relaxed italic mb-8 relative z-10">
                "{t.content}"
              </p>
              <div className="flex items-center gap-4">
                <img 
                  src={t.avatar} 
                  alt={t.name} 
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <h5 className="font-bold text-slate-900 dark:text-white leading-none">{t.name}</h5>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{t.role}, {t.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
