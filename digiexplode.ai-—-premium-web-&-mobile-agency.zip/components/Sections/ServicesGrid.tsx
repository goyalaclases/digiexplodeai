
import React from 'react';
import { services } from '../../data/services';
import * as Icons from 'lucide-react';

const ServicesGrid: React.FC = () => {
  return (
    <section className="py-24 bg-slate-50 dark:bg-slate-900/50" id="services">
      <div className="container mx-auto px-4 md:px-6">
        <header className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-[0.2em] mb-3">Professional Services</h2>
          <h3 className="text-3xl md:text-5xl font-extrabold text-slate-900 dark:text-white mb-6">Expert Website & App Development</h3>
          <p className="text-slate-600 dark:text-slate-400 text-lg">
            We deliver industry-leading website development services, custom SaaS solutions, and mobile apps that drive business ROI.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => {
            const IconComponent = (Icons as any)[service.icon];
            return (
              <article 
                key={service.id} 
                className="group p-8 bg-white dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-indigo-500 transition-all duration-300 hover:shadow-2xl hover:shadow-indigo-500/10"
              >
                <div className="w-14 h-14 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl flex items-center justify-center text-indigo-600 dark:text-indigo-400 mb-6 group-hover:scale-110 transition-transform">
                  {IconComponent && <IconComponent className="w-8 h-8" />}
                </div>
                <h4 className="text-xl font-bold text-slate-900 dark:text-white mb-4">{service.title}</h4>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed mb-6">
                  {service.description}
                </p>
                <div className="h-1 w-12 bg-indigo-600 group-hover:w-24 transition-all duration-300"></div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default ServicesGrid;
