
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { projects } from '../../data/projects';
import { Category } from '../../types';

const ProjectsGrid: React.FC<{ limit?: number }> = ({ limit }) => {
  const [filter, setFilter] = useState<Category>('All');
  
  const categories: Category[] = ['All', 'Website', 'Web App', 'Mobile App', 'UI/UX'];
  
  const filteredProjects = projects.filter(p => filter === 'All' || p.category === filter);
  const displayProjects = limit ? filteredProjects.slice(0, limit) : filteredProjects;

  return (
    <section className="py-24 bg-white dark:bg-slate-950">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16">
          <div className="max-w-2xl">
            <h2 className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-[0.2em] mb-3">Our Work Portfolio</h2>
            <h3 className="text-3xl md:text-5xl font-extrabold text-slate-900 dark:text-white mb-6">High-Performance Case Studies</h3>
            <p className="text-slate-600 dark:text-slate-400 text-lg">
              Explore how our website development agency helped startups and enterprises dominate their niche.
            </p>
          </div>
          
          <nav className="flex flex-wrap gap-2" aria-label="Project filter">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-6 py-2 rounded-full text-sm font-semibold transition-all ${
                  filter === cat 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200/50' 
                    : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800'
                }`}
                aria-pressed={filter === cat}
              >
                {cat}
              </button>
            ))}
          </nav>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayProjects.map((project) => (
            <Link 
              key={project.id}
              to={`/projects/${project.slug}`}
              className="group block"
              aria-label={`View case study for ${project.title}`}
            >
              <article>
                <div className="relative overflow-hidden rounded-3xl bg-slate-100 dark:bg-slate-900 aspect-[4/3] mb-6 shadow-sm group-hover:shadow-2xl transition-all duration-500">
                  <img 
                    src={project.image} 
                    alt={`${project.title} - ${project.category} development project by Digiexplode.AI`}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-8">
                    <span className="text-white font-bold flex items-center gap-2">
                      View Case Study <ArrowRight className="w-5 h-5" />
                    </span>
                  </div>
                  <div className="absolute top-6 left-6 px-4 py-1.5 bg-white/90 dark:bg-slate-950/90 backdrop-blur-md rounded-full text-xs font-bold text-slate-900 dark:text-white shadow-lg">
                    {project.category}
                  </div>
                </div>
                <h4 className="text-2xl font-bold text-slate-900 dark:text-white mb-2 group-hover:text-indigo-600 transition-colors">
                  {project.title}
                </h4>
                <p className="text-slate-600 dark:text-slate-400 text-sm mb-4 line-clamp-1">
                  Result: {project.outcome}
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.techStack.map((tech) => (
                    <span key={tech} className="px-2.5 py-1 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded text-[10px] font-bold text-slate-500 dark:text-slate-500 uppercase tracking-widest">
                      {tech}
                    </span>
                  ))}
                </div>
              </article>
            </Link>
          ))}
        </div>

        {limit && (
          <div className="mt-16 text-center">
            <Link 
              to="/projects" 
              className="inline-flex items-center gap-2 text-indigo-600 font-bold hover:gap-4 transition-all"
            >
              View All Professional Projects <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        )}
      </div>
    </section>
  );
};

export default ProjectsGrid;
