
import React, { useState } from 'react';
import { Send, CheckCircle, Mail, Phone, Loader2 } from 'lucide-react';
import { siteConfig } from '../../config/site';

const ContactForm: React.FC = () => {
  const [formState, setFormState] = useState<'idle' | 'loading' | 'success'>('idle');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    service: 'Website Design',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;
    
    setFormState('loading');
    
    // Simulate API call
    setTimeout(() => {
      setFormState('success');
      setFormData({ name: '', email: '', service: 'Website Design', message: '' });
    }, 1500);
  };

  if (formState === 'success') {
    return (
      <div className="py-32 text-center bg-white dark:bg-slate-950">
        <div className="inline-flex items-center justify-center w-24 h-24 bg-green-100 dark:bg-green-900/30 text-green-600 rounded-full mb-8 animate-bounce">
          <CheckCircle className="w-12 h-12" />
        </div>
        <h3 className="text-4xl font-extrabold text-slate-900 dark:text-white mb-4">Explosive Results Incoming!</h3>
        <p className="text-slate-600 dark:text-slate-400 mb-10 max-w-md mx-auto text-lg">
          We've received your inquiry. One of our experts will contact you within the next 2 hours.
        </p>
        <button 
          onClick={() => setFormState('idle')}
          className="px-10 py-4 bg-gradient-to-r from-purple-600 to-cyan-500 text-white rounded-2xl font-black shadow-xl"
        >
          Send Another Message
        </button>
      </div>
    );
  }

  return (
    <section className="py-24 bg-slate-50 dark:bg-slate-950" id="contact">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="inline-block px-4 py-1.5 mb-6 rounded-full bg-cyan-50 dark:bg-cyan-900/30 text-cyan-600 dark:text-cyan-400 text-xs font-bold uppercase tracking-widest">
              Contact Us
            </div>
            <h2 className="text-5xl md:text-6xl font-black text-slate-900 dark:text-white mb-8 tracking-tighter">Ready to <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-cyan-500">Explode</span> Your Brand?</h2>
            <p className="text-xl text-slate-600 dark:text-slate-400 mb-12 leading-relaxed font-medium">
              We're currently accepting new projects. Let's discuss your vision and turn it into a high-converting digital masterpiece.
            </p>
            
            <div className="space-y-8">
              <div className="flex items-start gap-5">
                <div className="w-14 h-14 bg-white dark:bg-slate-900 rounded-2xl shadow-md border border-slate-100 dark:border-slate-800 flex items-center justify-center text-purple-600">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <h5 className="font-black text-slate-900 dark:text-white uppercase tracking-widest text-xs mb-1">Email Our Team</h5>
                  <p className="text-slate-600 dark:text-slate-400 font-bold">{siteConfig.email}</p>
                </div>
              </div>
              <div className="flex items-start gap-5">
                <div className="w-14 h-14 bg-white dark:bg-slate-900 rounded-2xl shadow-md border border-slate-100 dark:border-slate-800 flex items-center justify-center text-cyan-500">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h5 className="font-black text-slate-900 dark:text-white uppercase tracking-widest text-xs mb-1">Call / WhatsApp</h5>
                  <p className="text-slate-600 dark:text-slate-400 font-bold">{siteConfig.phone}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-4 bg-gradient-to-r from-purple-600/20 to-cyan-500/20 rounded-[2.5rem] blur-2xl"></div>
            <div className="relative bg-white dark:bg-slate-900 p-8 md:p-12 rounded-[2rem] shadow-2xl border border-slate-50 dark:border-slate-800">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-black uppercase tracking-widest text-slate-500 mb-2 ml-1">Full Name</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Rahul Gupta"
                      className="w-full px-5 py-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all font-medium"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-black uppercase tracking-widest text-slate-500 mb-2 ml-1">Email Address</label>
                    <input 
                      type="email" 
                      required
                      placeholder="e.g. rahul@company.com"
                      className="w-full px-5 py-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all font-medium"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-black uppercase tracking-widest text-slate-500 mb-2 ml-1">Service Needed</label>
                  <select 
                    className="w-full px-5 py-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all appearance-none font-medium"
                    value={formData.service}
                    onChange={(e) => setFormData({...formData, service: e.target.value})}
                  >
                    <option>Website Design</option>
                    <option>E-Commerce Store</option>
                    <option>Web Application</option>
                    <option>Mobile App</option>
                    <option>UI/UX Project</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-black uppercase tracking-widest text-slate-500 mb-2 ml-1">Your Project Brief</label>
                  <textarea 
                    rows={4}
                    required
                    placeholder="Tell us about your goals, timeline, and budget..."
                    className="w-full px-5 py-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all resize-none font-medium"
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                  ></textarea>
                </div>
                <button 
                  type="submit"
                  disabled={formState === 'loading'}
                  className="w-full py-5 bg-gradient-to-r from-purple-600 to-cyan-500 hover:scale-[1.02] active:scale-[0.98] text-white rounded-2xl font-black text-xl transition-all flex items-center justify-center gap-3 disabled:opacity-70 shadow-lg shadow-cyan-500/20"
                >
                  {formState === 'loading' ? (
                    <><Loader2 className="w-6 h-6 animate-spin" /> Processing...</>
                  ) : (
                    <>Submit Proposal <Send className="w-6 h-6" /></>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactForm;
