
import React, { useState, useEffect } from 'react';
import { Check, Sparkles, Smartphone, Globe } from 'lucide-react';
import { webPricingPlans, androidPricingPlans } from '../../data/pricing';
import { siteConfig } from '../../config/site';
import { PricingPlan } from '../../types';

const Pricing: React.FC = () => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');
  const [showToast, setShowToast] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    let timer: number;
    let exitTimer: number;

    if (showToast && !isExiting) {
      timer = window.setTimeout(() => {
        setIsExiting(true);
        exitTimer = window.setTimeout(() => {
          setShowToast(false);
          setIsExiting(false);
        }, 500);
      }, 2000);
    }

    return () => {
      clearTimeout(timer);
      clearTimeout(exitTimer);
    };
  }, [showToast, isExiting]);

  const toggleBilling = () => {
    const nextCycle = billingCycle === 'monthly' ? 'annual' : 'monthly';
    setBillingCycle(nextCycle);
    if (nextCycle === 'annual') {
      setShowToast(true);
      setIsExiting(false);
    }
  };

  const getWhatsAppLink = (planName: string) => {
    const message = encodeURIComponent(`Hi DigiexplodeAI team, I'm interested in the ${planName} (${billingCycle}) plan for my project.`);
    const cleanPhone = siteConfig.phone.replace(/\D/g, '');
    return `https://wa.me/${cleanPhone}?text=${message}`;
  };

  const PricingGrid = ({ plans, title, icon: Icon }: { plans: PricingPlan[], title: string, icon: any }) => (
    <div className="mb-24 last:mb-0">
      <div className="flex items-center justify-center gap-3 mb-12">
        <div className="w-10 h-10 bg-indigo-500/10 rounded-xl flex items-center justify-center text-indigo-500">
          <Icon className="w-6 h-6" />
        </div>
        <h3 className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">{title}</h3>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {plans.map((plan) => (
          <div 
            key={plan.id}
            className={`relative p-8 rounded-[2.5rem] border transition-all duration-500 flex flex-col ${
              plan.popular 
                ? 'bg-white dark:bg-slate-950 border-cyan-500 shadow-2xl scale-105 z-10' 
                : 'bg-white dark:bg-slate-950 border-slate-100 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-600'
            }`}
          >
            {plan.popular && (
              <div className="absolute top-0 right-8 -translate-y-1/2 px-4 py-1 bg-gradient-to-r from-purple-600 to-cyan-500 text-white text-[10px] font-black rounded-full uppercase tracking-widest">
                Recommended
              </div>
            )}
            
            <div className="mb-8">
              <h4 className="text-xl font-bold text-slate-900 dark:text-white mb-2">{plan.name}</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 font-medium leading-relaxed">{plan.description}</p>
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-extrabold text-slate-900 dark:text-white transition-all duration-300">
                  {billingCycle === 'monthly' ? plan.monthlyPrice : plan.annualPrice}
                </span>
                <span className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">/ {billingCycle === 'monthly' ? 'mo' : 'mo (billed annual)'}</span>
              </div>
            </div>

            <ul className="space-y-4 mb-10 flex-grow">
              {plan.features.map((feature, i) => (
                <li key={i} className="flex items-start gap-3 text-sm text-slate-600 dark:text-slate-400 font-medium">
                  <Check className="w-4 h-4 text-cyan-500 mt-1 shrink-0" />
                  {feature}
                </li>
              ))}
            </ul>

            <a 
              href={getWhatsAppLink(plan.name)}
              target="_blank"
              rel="noopener noreferrer"
              className={`w-full py-4 rounded-2xl font-black text-sm uppercase tracking-widest text-center transition-all ${
                plan.popular 
                  ? 'bg-gradient-to-r from-purple-600 to-cyan-500 text-white hover:opacity-90 shadow-lg shadow-cyan-500/20' 
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              Get Started
            </a>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <section className="relative py-24 bg-slate-50 dark:bg-slate-950 overflow-hidden">
      {/* 3D Evaporating Popup */}
      {showToast && (
        <div className="fixed inset-0 flex items-center justify-center z-[100] pointer-events-none px-4">
          <style>{`
            @keyframes evaporate {
              0% { transform: perspective(1000px) rotateX(10deg) scale(1) translateY(0); opacity: 1; filter: blur(0px); }
              100% { transform: perspective(1000px) rotateX(20deg) scale(1.1) translateY(-100px); opacity: 0; filter: blur(20px); }
            }
            .animate-evaporate {
              animation: evaporate 0.6s cubic-bezier(0.4, 0, 0.2, 1) forwards;
            }
            .three-d-shadow {
              box-shadow: 
                0 10px 20px -5px rgba(0, 0, 0, 0.3),
                0 20px 40px -10px rgba(139, 92, 246, 0.3),
                inset 0 0 15px rgba(255, 255, 255, 0.2);
            }
          `}</style>
          
          <div className={`relative ${isExiting ? 'animate-evaporate' : 'animate-in zoom-in-90 fade-in duration-500'}`}>
            <div className="absolute -inset-10 bg-gradient-to-r from-purple-600/40 to-cyan-500/40 blur-[100px] animate-pulse"></div>
            <div 
              className="relative bg-white/80 dark:bg-slate-900/90 backdrop-blur-2xl border-x border-t border-white/30 dark:border-white/10 rounded-[4rem] px-16 py-12 three-d-shadow transform transition-transform"
              style={{ transform: 'perspective(1000px) rotateX(10deg)' }}
            >
              <div className="absolute inset-x-0 -bottom-2 h-4 bg-slate-200 dark:bg-slate-800 rounded-b-[4rem] -z-10"></div>
              <div className="flex flex-col items-center gap-6">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-600 to-cyan-500 rounded-3xl flex items-center justify-center text-white shadow-[0_10px_30px_rgba(139,92,246,0.5)] rotate-6">
                  <Sparkles className="w-10 h-10 animate-pulse" />
                </div>
                <div className="text-center">
                  <h3 className="text-4xl md:text-6xl font-[1000] text-slate-900 dark:text-white leading-none tracking-tighter mb-2">
                    SAVE <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-cyan-500">UP TO 20%</span>
                  </h3>
                  <p className="text-slate-500 dark:text-slate-400 font-black uppercase tracking-[0.4em] text-[10px]">Annual Mode Active</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-20">
          <h2 className="text-3xl md:text-5xl font-black text-slate-900 dark:text-white mb-6 tracking-tighter uppercase">Premium Service Tiers</h2>
          <p className="text-slate-600 dark:text-slate-400 text-lg max-w-2xl mx-auto mb-12 font-medium">
            Transparent pricing for brands that demand excellence. Whether it's web or mobile, we've got you covered.
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-4">
            <span className={`text-xs font-black uppercase tracking-widest transition-colors ${billingCycle === 'monthly' ? 'text-slate-900 dark:text-white' : 'text-slate-400'}`}>Monthly</span>
            <button 
              onClick={toggleBilling}
              className="relative w-16 h-8 bg-slate-200 dark:bg-slate-800 rounded-full p-1 transition-colors duration-300 focus:outline-none"
              aria-label="Toggle billing cycle"
            >
              <div className={`w-6 h-6 bg-white dark:bg-purple-500 rounded-full shadow-md transform transition-transform duration-300 ${billingCycle === 'annual' ? 'translate-x-8' : 'translate-x-0'}`}></div>
            </button>
            <div className="flex items-center gap-2">
              <span className={`text-xs font-black uppercase tracking-widest transition-colors ${billingCycle === 'annual' ? 'text-slate-900 dark:text-white' : 'text-slate-400'}`}>Annual</span>
              <span className="bg-green-100 dark:bg-green-900/30 text-green-600 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">Save 20%</span>
            </div>
          </div>
        </div>

        {/* Website Section */}
        <PricingGrid plans={webPricingPlans} title="Website Solutions" icon={Globe} />
        
        {/* Separator */}
        <div className="my-20 flex items-center gap-8 opacity-20">
          <div className="h-px flex-grow bg-gradient-to-r from-transparent via-slate-400 to-transparent"></div>
          <Sparkles className="w-5 h-5 text-slate-400" />
          <div className="h-px flex-grow bg-gradient-to-r from-transparent via-slate-400 to-transparent"></div>
        </div>

        {/* Android Section */}
        <PricingGrid plans={androidPricingPlans} title="Android App Solutions" icon={Smartphone} />
      </div>
    </section>
  );
};

export default Pricing;
