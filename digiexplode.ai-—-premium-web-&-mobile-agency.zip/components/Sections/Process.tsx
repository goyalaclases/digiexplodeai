
import React from 'react';

const steps = [
  { title: "Discover", desc: "Consultation, strategy, and roadmap development.", icon: "01" },
  { title: "UI/UX", desc: "Interactive wireframes and high-fidelity prototypes.", icon: "02" },
  { title: "Development", desc: "Robust coding with modern stacks for speed & scale.", icon: "03" },
  { title: "Testing", desc: "Quality assurance across devices and browsers.", icon: "04" },
  { title: "Launch & Support", desc: "Deployment and continuous optimization.", icon: "05" }
];

const Process: React.FC = () => {
  return (
    <section className="py-24 bg-white dark:bg-slate-950">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-extrabold text-slate-900 dark:text-white mb-6">How We Work</h2>
          <p className="text-slate-600 dark:text-slate-400 text-lg max-w-2xl mx-auto">
            A transparent and proven process to take your project from idea to impact.
          </p>
        </div>

        <div className="relative">
          {/* Timeline Connector Desktop */}
          <div className="hidden lg:block absolute top-1/2 left-0 w-full h-0.5 bg-slate-100 dark:bg-slate-800 -translate-y-1/2 z-0"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 relative z-10">
            {steps.map((step, idx) => (
              <div key={idx} className="group flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-white dark:bg-slate-900 border-4 border-slate-50 dark:border-slate-800 flex items-center justify-center text-indigo-600 dark:text-indigo-400 text-2xl font-black mb-6 group-hover:border-indigo-600 transition-all duration-300">
                  {step.icon}
                </div>
                <h4 className="text-xl font-bold text-slate-900 dark:text-white mb-3">{step.title}</h4>
                <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed max-w-[200px]">
                  {step.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Process;
