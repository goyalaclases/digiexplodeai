
export const siteConfig = {
  brandName: "DigiexplodeAI",
  tagline: "Digital Dreams, Explosive Result",
  email: "digiexploadai@gmail.com",
  phone: "+91 8725072730",
  whatsappLink: "https://wa.me/918725072730?text=Hi%20DigiexplodeAI,%20I'm%20interested%20in%20transforming%20my%20digital%20dreams%20into%20explosive%20results!",
  social: {
    linkedin: "https://linkedin.com/company/digiexplode",
    twitter: "https://twitter.com/digiexplode",
    instagram: "https://instagram.com/digiexplode",
    github: "https://github.com/digiexplode"
  },
  address: "Innovate Hub, Sector 62, Noida, India",
  trustPoints: [
    "Premium Branding",
    "Explosive Performance",
    "Digital-First Approach",
    "SEO Dominance"
  ],
  seoKeywords: [
    "DigiexplodeAI",
    "Digital Dreams Explosive Result",
    "Premium Website Development",
    "High-End UI/UX Agency",
    "SaaS and Mobile App Experts"
  ]
};
