
import { Service } from '../types';

export const services: Service[] = [
  {
    id: 1,
    title: "Website Design & Development",
    description: "High-performance websites that look premium and convert visitors into customers.",
    icon: "Monitor"
  },
  {
    id: 2,
    title: "E-Commerce Store Setup",
    description: "Complete online stores with seamless payment gateway and shipping integrations.",
    icon: "ShoppingBag"
  },
  {
    id: 3,
    title: "Web Apps & Admin Panels",
    description: "Custom dashboards, CRM tools, and internal portals tailored to your business operations.",
    icon: "LayoutDashboard"
  },
  {
    id: 4,
    title: "Mobile Apps (Android/iOS)",
    description: "Feature-rich native and cross-platform mobile applications for the modern user.",
    icon: "Smartphone"
  },
  {
    id: 5,
    title: "UI/UX Design",
    description: "User-centric interface designs in Figma that prioritize usability and brand aesthetics.",
    icon: "Palette"
  },
  {
    id: 6,
    title: "Maintenance & Speed",
    description: "Regular updates, hosting management, speed optimization, and basic SEO support.",
    icon: "ShieldCheck"
  }
];
