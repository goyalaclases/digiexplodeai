
import { PricingPlan } from '../types';

export const webPricingPlans: PricingPlan[] = [
  {
    id: 'starter',
    name: "Web Starter",
    monthlyPrice: "₹4,999",
    annualPrice: "₹3,999",
    description: "Perfect for personal brands and single-page landing pages.",
    features: [
      "1-Page Premium Website",
      "Basic SEO Setup",
      "Contact Form Integration"
    ]
  },
  {
    id: 'growth',
    name: "Web Growth",
    monthlyPrice: "₹14,999",
    annualPrice: "₹11,999",
    description: "Ideal for growing businesses needing more power.",
    features: [
      "4-Pages Premium Website",
      "Dynamic Web Application",
      "Advanced UI Animations",
      "Speed Optimization"
    ],
    popular: true
  },
  {
    id: 'pro',
    name: "Web Pro",
    monthlyPrice: "₹24,999",
    annualPrice: "₹19,999",
    description: "Custom solutions for enterprises and startups.",
    features: [
      "Full Custom Web/Mobile App",
      "E-Commerce Functionality",
      "Dedicated Admin Dashboard",
      "Complex API Integrations",
      "Premium UI/UX System",
      "Hosting & Deployment"
    ]
  }
];

export const androidPricingPlans: PricingPlan[] = [
  {
    id: 'android-lite',
    name: "Android Lite",
    monthlyPrice: "₹9,999",
    annualPrice: "₹7,999",
    description: "The complete digital start: Simple utility app + a professional web landing page.",
    features: [
      "Android App",
      "1-Page Premium Website",
      "Basic SEO & Contact Setup",
      "Basic UI/UX Design",
      "Cloudflare Integration"
    ]
  },
  {
    id: 'android-business',
    name: "Android Business",
    monthlyPrice: "₹59,999",
    annualPrice: "₹47,999",
    description: "Full-scale app for businesses needing growth and engagement.",
    features: [
      "Custom UI/UX Prototypes",
      "Push Notifications",
      "Payment Gateway Integration",
      "Advanced API Connection",
      "Play Store Submission"
    ],
    popular: true
  },
  {
    id: 'android-enterprise',
    name: "Android Enterprise",
    monthlyPrice: "₹1,49,999",
    annualPrice: "₹1,19,999",
    description: "Scalable enterprise-grade apps with high-security needs.",
    features: [
      "High-Security Architecture",
      "Offline Mode Support",
      "Real-time Data Sync",
      "AI/Machine Learning Models",
      "Dedicated Project Manager",
      "24/7 Priority Support"
    ]
  }
];

// Combine for backward compatibility if needed elsewhere
export const pricingPlans = [...webPricingPlans, ...androidPricingPlans];
