
import { Testimonial } from '../types';

export const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Rahul Sharma",
    role: "Founder",
    company: "FitEdge Gym",
    content: "Digiexplode.AI transformed our online presence. Our lead generation tripled within the first month of launching our new site.",
    avatar: "https://picsum.photos/seed/rahul/100/100"
  },
  {
    id: 2,
    name: "Priya Varma",
    role: "Marketing Head",
    company: "Luxe Decor",
    content: "The attention to detail in their UI/UX design is unmatched. They truly understood our brand's premium positioning.",
    avatar: "https://picsum.photos/seed/priya/100/100"
  },
  {
    id: 3,
    name: "Amit Patel",
    role: "CEO",
    company: "TechFlow Solutions",
    content: "Speed and performance were our main concerns. Digiexplode delivered a blazing-fast dashboard that our clients love.",
    avatar: "https://picsum.photos/seed/amit/100/100"
  }
];
