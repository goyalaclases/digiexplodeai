
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Rocket, Target, DollarSign, Clock, CheckCircle2, ArrowRight, ArrowLeft, Loader2, HelpCircle } from 'lucide-react';

const StartProject: React.FC = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [formData, setFormData] = useState({
    type: '',
    budget: '',
    timeline: '',
    details: ''
  });

  const nextStep = () => setStep(s => s + 1);
  const prevStep = () => setStep(s => s - 1);

  const handleSubmit = async () => {
    setIsSubmitting(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsSubmitting(false);
    setIsSuccess(true);
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-24 pb-20 px-4">
        <div className="max-w-md w-full text-center bg-white dark:bg-slate-900 p-12 rounded-[3rem] shadow-2xl border border-slate-100 dark:border-slate-800 animate-in zoom-in duration-500">
          <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 text-green-600 rounded-full flex items-center justify-center mx-auto mb-8">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-4">Discovery Started!</h2>
          <p className="text-slate-600 dark:text-slate-400 mb-10 leading-relaxed">
            Your digital dream is now in our hands. Our strategy team will reach out within 2 hours to finalize the roadmap.
          </p>
          <button 
            onClick={() => navigate('/')}
            className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-bold hover:scale-105 transition-all"
          >
            Back to Homepage
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-32 pb-20 bg-slate-50 dark:bg-slate-950 px-4">
      <div className="max-w-3xl mx-auto">
        {/* Progress Bar */}
        <div className="mb-12 flex items-center justify-between">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex flex-col items-center gap-2 relative">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm border-2 transition-all ${
                step >= s ? 'bg-purple-600 border-purple-600 text-white' : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400'
              }`}>
                {step > s ? <CheckCircle2 className="w-5 h-5" /> : s}
              </div>
              <span className={`text-[10px] uppercase tracking-widest font-black ${step >= s ? 'text-purple-600' : 'text-slate-400'}`}>
                {s === 1 ? 'Objective' : s === 2 ? 'Details' : 'Confirm'}
              </span>
              {s < 3 && (
                <div className={`absolute left-14 top-5 h-0.5 w-24 md:w-48 transition-all ${step > s ? 'bg-purple-600' : 'bg-slate-200 dark:bg-slate-800'}`}></div>
              )}
            </div>
          ))}
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-8 md:p-12 shadow-2xl border border-slate-50 dark:border-slate-800">
          {step === 1 && (
            <div className="animate-in slide-in-from-right-8 duration-500">
              <h2 className="text-3xl md:text-4xl font-black text-slate-900 dark:text-white mb-8">What are we building today?</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { id: 'web', label: 'E-Commerce Store', icon: Rocket },
                  { id: 'app', label: 'Custom Web App', icon: Target },
                  { id: 'mobile', label: 'Mobile Application', icon: Rocket },
                  { id: 'lms', label: 'LMS Portal', icon: CheckCircle2 },
                  { id: 'other', label: 'Other / Custom', icon: HelpCircle },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setFormData({...formData, type: item.label})}
                    className={`p-6 rounded-2xl border-2 text-left transition-all flex items-center gap-4 group ${
                      formData.type === item.label 
                        ? 'border-purple-600 bg-purple-50 dark:bg-purple-900/10' 
                        : 'border-slate-100 dark:border-slate-800 hover:border-slate-200 dark:hover:border-slate-700'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
                      formData.type === item.label ? 'bg-purple-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 group-hover:bg-slate-200'
                    }`}>
                      <item.icon className="w-6 h-6" />
                    </div>
                    <span className={`font-bold ${formData.type === item.label ? 'text-purple-700 dark:text-purple-400' : 'text-slate-600 dark:text-slate-400'}`}>
                      {item.label}
                    </span>
                  </button>
                ))}
              </div>
              
              <div className="mt-8 p-6 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 text-center">
                <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">
                  Have a unique idea that doesn't fit these categories? <br className="hidden md:block" /> 
                  Select <span className="text-purple-600 font-bold">Other / Custom</span> and we'll help you refine it like any other project.
                </p>
              </div>

              <div className="mt-12 flex justify-end">
                <button 
                  disabled={!formData.type}
                  onClick={nextStep}
                  className="px-8 py-4 bg-gradient-to-r from-purple-600 to-cyan-500 text-white rounded-2xl font-bold flex items-center gap-2 hover:scale-105 transition-all disabled:opacity-50 disabled:hover:scale-100"
                >
                  Continue <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="animate-in slide-in-from-right-8 duration-500">
              <h2 className="text-3xl md:text-4xl font-black text-slate-900 dark:text-white mb-8">Investment & Timeline</h2>
              <div className="space-y-8">
                <div>
                  <label className="block text-xs font-black uppercase tracking-widest text-slate-500 mb-4 flex items-center gap-2">
                    <DollarSign className="w-4 h-4" /> Planned Budget Range
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {['< ₹50k', '₹50k - ₹1.5L', '₹1.5L - ₹5L', '₹5L+'].map((b) => (
                      <button 
                        key={b}
                        onClick={() => setFormData({...formData, budget: b})}
                        className={`py-3 rounded-xl border-2 font-bold text-sm transition-all ${
                          formData.budget === b ? 'border-purple-600 bg-purple-50 dark:bg-purple-900/10 text-purple-600' : 'border-slate-100 dark:border-slate-800 text-slate-500 hover:border-slate-200'
                        }`}
                      >
                        {b}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black uppercase tracking-widest text-slate-500 mb-4 flex items-center gap-2">
                    <Clock className="w-4 h-4" /> Desired Launch
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {['2-4 Weeks', '1-3 Months', '3 Months+', 'Flexible'].map((t) => (
                      <button 
                        key={t}
                        onClick={() => setFormData({...formData, timeline: t})}
                        className={`py-3 rounded-xl border-2 font-bold text-sm transition-all ${
                          formData.timeline === t ? 'border-purple-600 bg-purple-50 dark:bg-purple-900/10 text-purple-600' : 'border-slate-100 dark:border-slate-800 text-slate-500 hover:border-slate-200'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="mt-12 flex justify-between">
                <button onClick={prevStep} className="px-6 py-4 text-slate-500 font-bold flex items-center gap-2 hover:text-slate-800 dark:hover:text-white transition-colors">
                  <ArrowLeft className="w-5 h-5" /> Back
                </button>
                <button 
                  disabled={!formData.budget || !formData.timeline}
                  onClick={nextStep}
                  className="px-8 py-4 bg-gradient-to-r from-purple-600 to-cyan-500 text-white rounded-2xl font-bold flex items-center gap-2 hover:scale-105 transition-all disabled:opacity-50"
                >
                  Almost there <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="animate-in slide-in-from-right-8 duration-500 text-center">
              <h2 className="text-3xl md:text-4xl font-black text-slate-900 dark:text-white mb-4">You're Ready to Explode!</h2>
              <p className="text-slate-500 dark:text-slate-400 mb-8 font-medium">Review your project brief and submit to start the transformation.</p>
              
              <div className="bg-slate-50 dark:bg-slate-950/50 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 text-left mb-8 space-y-4">
                <div className="flex justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                  <span className="text-xs font-black uppercase tracking-widest text-slate-400">Project Type</span>
                  <span className="font-bold text-purple-600">{formData.type}</span>
                </div>
                <div className="flex justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                  <span className="text-xs font-black uppercase tracking-widest text-slate-400">Budget Range</span>
                  <span className="font-bold text-purple-600">{formData.budget}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs font-black uppercase tracking-widest text-slate-400">Timeline</span>
                  <span className="font-bold text-purple-600">{formData.timeline}</span>
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <button 
                  disabled={isSubmitting}
                  onClick={handleSubmit}
                  className="w-full py-5 bg-gradient-to-r from-purple-600 to-cyan-500 text-white rounded-2xl font-black text-xl hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 shadow-xl shadow-cyan-500/20 disabled:opacity-70"
                >
                  {isSubmitting ? (
                    <><Loader2 className="w-6 h-6 animate-spin" /> Preparing Launch...</>
                  ) : (
                    <>Submit Project Brief <Rocket className="w-6 h-6" /></>
                  )}
                </button>
                <button onClick={prevStep} className="py-4 text-slate-500 font-bold hover:text-slate-800 transition-colors">
                  Edit Details
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StartProject;
