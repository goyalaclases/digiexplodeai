
import React, { useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle2, ExternalLink, MessageCircle } from 'lucide-react';
import { projects } from '../data/projects';
import { siteConfig } from '../config/site';

const ProjectDetail: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const project = projects.find(p => p.slug === slug);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center text-center p-6">
        <div>
          <h2 className="text-3xl font-bold mb-4">Project Not Found</h2>
          <Link to="/projects" className="text-indigo-600 font-bold">Back to All Projects</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-20 animate-in slide-in-from-bottom-4 duration-500">
      <div className="container mx-auto px-4 md:px-6">
        <button 
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 text-slate-500 hover:text-indigo-600 transition-colors mb-12 font-semibold"
        >
          <ArrowLeft className="w-5 h-5" /> Back to Work
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
          <div>
            <div className="inline-block px-4 py-1.5 mb-6 rounded-full bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 text-xs font-bold uppercase tracking-widest">
              Case Study: {project.category}
            </div>
            <h1 className="text-4xl md:text-6xl font-extrabold text-slate-900 dark:text-white mb-6 leading-tight">
              {project.title}
            </h1>
            <p className="text-xl text-slate-600 dark:text-slate-400 mb-8 leading-relaxed">
              {project.fullDescription}
            </p>
            
            <div className="flex flex-wrap gap-4 mb-10">
              {project.techStack.map(tech => (
                <span key={tech} className="px-4 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl text-sm font-bold text-slate-600 dark:text-slate-400">
                  {tech}
                </span>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href={siteConfig.whatsappLink}
                className="px-8 py-4 bg-indigo-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-xl shadow-indigo-200/20"
              >
                Start a Project <MessageCircle className="w-5 h-5" />
              </a>
              {project.liveUrl && (
                <a 
                  href={project.liveUrl}
                  target="_blank"
                  className="px-8 py-4 bg-white dark:bg-slate-900 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl font-bold flex items-center justify-center gap-2"
                >
                  Live Demo <ExternalLink className="w-5 h-5" />
                </a>
              )}
            </div>
          </div>
          
          <div className="relative">
            <div className="aspect-[4/3] rounded-[2.5rem] overflow-hidden shadow-2xl">
              <img 
                src={project.image} 
                alt={project.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-8 -left-8 p-8 bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 hidden md:block max-w-xs">
              <p className="text-indigo-600 font-bold mb-2 uppercase text-xs tracking-widest">Key Result</p>
              <p className="text-slate-900 dark:text-white font-extrabold text-xl">{project.outcome}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-20 border-t border-slate-100 dark:border-slate-800 pt-20">
          <div>
            <h3 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <span className="w-8 h-8 rounded-lg bg-red-100 dark:bg-red-900/30 text-red-600 flex items-center justify-center font-bold">!</span>
              The Problem
            </h3>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
              {project.problem}
            </p>
          </div>
          <div>
            <h3 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <span className="w-8 h-8 rounded-lg bg-green-100 dark:bg-green-900/30 text-green-600 flex items-center justify-center font-bold">✓</span>
              The Solution
            </h3>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
              {project.solution}
            </p>
          </div>
          <div>
            <h3 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <span className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 flex items-center justify-center font-bold">★</span>
              Features
            </h3>
            <ul className="space-y-3">
              {project.features.map((f, i) => (
                <li key={i} className="flex items-center gap-2 text-slate-600 dark:text-slate-400 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetail;
