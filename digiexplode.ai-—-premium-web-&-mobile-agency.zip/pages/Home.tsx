
import React from 'react';
import Hero from '../components/Sections/Hero';
import ServicesGrid from '../components/Sections/ServicesGrid';
import ProjectsGrid from '../components/Sections/ProjectsGrid';
import Process from '../components/Sections/Process';
import Pricing from '../components/Sections/Pricing';
import Testimonials from '../components/Sections/Testimonials';
import ContactForm from '../components/Sections/ContactForm';

const Home: React.FC = () => {
  return (
    <div className="animate-in fade-in duration-700">
      <Hero />
      <ServicesGrid />
      <ProjectsGrid limit={6} />
      <Process />
      <Pricing />
      <Testimonials />
      <ContactForm />
    </div>
  );
};

export default Home;
