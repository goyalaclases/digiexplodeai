
import React, { useState } from 'react';
import { siteConfig } from '../config/site';
import { ArrowRight, Code, Laptop, Rocket, Users, Loader2, CheckCircle } from 'lucide-react';

const About: React.FC = () => {
  const [downloadState, setDownloadState] = useState<'idle' | 'loading' | 'done'>('idle');

  const handleDownload = () => {
    setDownloadState('loading');
    // Simulate generation and download
    setTimeout(() => {
      setDownloadState('done');
      // In a real app, you'd trigger a file download here
      setTimeout(() => setDownloadState('idle'), 3000);
    }, 2000);
  };

  return (
    <div className="pt-24 pb-20 animate-in fade-in duration-700">
      {/* Hero Header */}
      <section className="bg-slate-50 dark:bg-slate-950 py-20 mb-20">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-4xl">
            <h1 className="text-5xl md:text-7xl font-extrabold text-slate-900 dark:text-white mb-8">
              We build tools that <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-cyan-500">empower</span> businesses.
            </h1>
            <p className="text-xl md:text-2xl text-slate-600 dark:text-slate-400 leading-relaxed">
              DigiexplodeAI is a premium collective of designers and developers dedicated to crafting digital excellence. 
              We don't just build websites; we build growth engines.
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center mb-20">
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-cyan-500 rounded-[3rem] blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
            <img 
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=800" 
              alt="Our Team Working on Digital Dreams" 
              className="relative rounded-[3rem] shadow-2xl transition-transform group-hover:scale-[1.01]"
            />
          </div>
          <div className="space-y-8">
            <h2 className="text-4xl font-bold text-slate-900 dark:text-white">Our Story</h2>
            <p className="text-lg text-slate-600 dark:text-slate-400 leading-relaxed">
              Founded on the principle that "average is invisible," DigiexplodeAI was born out of a desire to bring high-end agency quality to ambitious startups and scaling businesses. 
              We focus on the intersection of aesthetics and performance.
            </p>
            <div className="grid grid-cols-2 gap-8">
              <div>
                <h4 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-cyan-500 mb-1">50+</h4>
                <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Projects Delivered</p>
              </div>
              <div>
                <h4 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-cyan-500 mb-1">98%</h4>
                <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Client Satisfaction</p>
              </div>
            </div>
            <button 
              onClick={handleDownload}
              disabled={downloadState === 'loading'}
              className={`px-8 py-4 rounded-xl font-bold flex items-center gap-2 transition-all shadow-xl ${
                downloadState === 'done' 
                  ? 'bg-green-500 text-white' 
                  : 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:scale-105 active:scale-95 disabled:opacity-70'
              }`}
            >
              {downloadState === 'idle' && (
                <>Download Our Brochure <ArrowRight className="w-5 h-5" /></>
              )}
              {downloadState === 'loading' && (
                <>Preparing Brochure... <Loader2 className="w-5 h-5 animate-spin" /></>
              )}
              {downloadState === 'done' && (
                <>Brochure Downloaded <CheckCircle className="w-5 h-5" /></>
              )}
            </button>
          </div>
        </div>

        <div className="bg-gradient-to-br from-slate-900 to-slate-950 dark:from-slate-900/50 dark:to-slate-950/50 rounded-[3rem] p-12 md:p-20 text-white mb-20 border border-slate-800">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            <div className="space-y-4">
              <Users className="w-10 h-10 text-purple-400" />
              <h4 className="text-xl font-bold">User-First</h4>
              <p className="text-slate-400 text-sm">We design for humans, not just algorithms. Experience is our priority.</p>
            </div>
            <div className="space-y-4">
              <Laptop className="w-10 h-10 text-cyan-400" />
              <h4 className="text-xl font-bold">Speed-Obsessed</h4>
              <p className="text-slate-400 text-sm">Every millisecond counts for conversion. We target sub-second load times.</p>
            </div>
            <div className="space-y-4">
              <Code className="w-10 h-10 text-purple-400" />
              <h4 className="text-xl font-bold">Modern Stack</h4>
              <p className="text-slate-400 text-sm">React, Next.js, and Tailwind CSS. We use the best tools for the job.</p>
            </div>
            <div className="space-y-4">
              <Rocket className="w-10 h-10 text-cyan-400" />
              <h4 className="text-xl font-bold">Scale Ready</h4>
              <p className="text-slate-400 text-sm">Built to grow as your business explodes. Architecture that lasts years.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
