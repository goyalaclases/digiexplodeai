
import React from 'react';
import ContactForm from '../components/Sections/ContactForm';

const Contact: React.FC = () => {
  return (
    <div className="pt-24 min-h-screen">
       <div className="bg-white dark:bg-slate-950 py-20 text-center border-b border-slate-100 dark:border-slate-800">
         <div className="container mx-auto px-4 md:px-6">
           <h1 className="text-5xl md:text-7xl font-extrabold text-slate-900 dark:text-white mb-6">Let's Talk</h1>
           <p className="text-xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
             Have a project in mind? We'd love to hear from you. 
             Average response time: 2 hours.
           </p>
         </div>
       </div>
       <ContactForm />
    </div>
  );
};

export default Contact;
