
import React, { useState } from 'react';
import ProjectsGrid from '../components/Sections/ProjectsGrid';

const Projects: React.FC = () => {
  return (
    <div className="pt-24 min-h-screen">
      <div className="bg-slate-50 dark:bg-slate-950 py-16">
        <div className="container mx-auto px-4 md:px-6">
          <h1 className="text-4xl md:text-6xl font-extrabold text-slate-900 dark:text-white mb-6">Our Work</h1>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl">
            A deep dive into our portfolio of premium websites, web apps, and mobile applications. 
            Each project represents a unique challenge solved with clean code and high-end design.
          </p>
        </div>
      </div>
      <ProjectsGrid />
    </div>
  );
};

export default Projects;
